//: .\C03:TESTHEADER_Sieve.cpp
//: C03:Sieve.h
// From "Thinking in C++, Volume 2", by Bruce Eckel & Chuck Allison.
// (c) 1995-2004 MindView, Inc. All Rights Reserved.
// See source code use permissions stated in the file 'License.txt',
// distributed with the code package available at www.MindView.net.
// Create a 50 char string and set each
// element to 'P' for Prime:
// By definition neither 0 nor 1 is prime.
// Change these elements to "N" for Not Prime:
// Walk through the array:
// Find all the multiples:
// SIEVE_H ///:~
#include"Sieve.h"
int main() {}
